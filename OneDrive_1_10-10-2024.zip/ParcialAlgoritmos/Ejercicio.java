import java.util.Scanner;
public class Ejercicio {
    private static int[] arreglo = new int[100]; // se declara un arreglo de enteros
private static int cantidadDatos = 0; //Se declara para realizar un seguimiento del número actual de elementos en el array
//Es 0 ya que está vacío

//Se procede a realizar las funciones
private static int posInsert(int valor){
    int i = 0;
    while ( i < cantidadDatos && arreglo[i] < valor){
        i++;
    }
    return i; 
}
private static boolean vacio(){
    return cantidadDatos == 0;
}
private static void insertarDato(int valor){
    int pos = posInsert(valor);
    if (cantidadDatos < 100){
        //Este pedazo desplaza los elemtnos del arreglo hacía la derecha para hacer espacio
        int i = cantidadDatos;
        while (i > pos) {
            arreglo [i]= arreglo [i-1];
            i--;
            
        }
        arreglo[pos] = valor;
        cantidadDatos ++; 
    }
}
private static void elimina(int valor){
    int i = 0;
    while (i < cantidadDatos && arreglo[i] != valor){
        i++;
    }
    if (i < cantidadDatos) {
        // se desplazan los elementos a la izquierda para elimnar el valor
        int j = i;
        while (j < cantidadDatos - 1) {
            arreglo[j] = arreglo[j + 1]; 
                j++ ;
            }
            cantidadDatos++; 
        }
        // se muestran los arreglos de forma ascendente y descente.
    }
    private static void ascendente(){
        System.out.println("El array organizado de forma ascendete queda así:");
        System.out.println("");
        int i = 0;
        while (i < cantidadDatos) {
            System.out.print("[" + arreglo[i] + "]," + " ");
            i++;
            
        }
        System.out.println();
    }
    private static void descendente(){
        System.out.println("El array organizado de forma descendentemente queda asi:");
        int i = cantidadDatos - 1;
        while (i >= 0) {
             System.out.print("[" + arreglo[i] + "]," + " ");
             i--;
            
        }
        System.out.println();
    }
    private static void lugar() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese el valor a buscar el mejor lugar: ");
        int valor = scanner.nextInt();

        int pos = posInsert(valor);

        System.out.println("El mejor lugar para insertar el valor " + valor + " es en la posicion " + pos);
    }
    //PROGRAMA PRINCIPAL
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        //Mensajes de bienvenida al usuario
        System.out.println("Progama de ordenamiento de arrays 2.0");
        System.out.println("En este pograma podrá ingresar una cantidad x de números enteros");
        // denifimos la variable opcion como entera
        int opc;
        //Se le solicita al usuario ingresar la opción del menú
        //y se muestran las opciones del menú
        System.out.println("Seleccione una opción númerica.");
        do{ //Este "do" hace que se repita la condicion con el while de abajo mientras sea cierta
        System.out.println("1. Insetar un número dentro del arreglo.");
        System.out.println("2. Seleccionar el número que deseé eliminar (ingrese el número).");
        System.out.println("3. Ver el arreglo de forma ascendente.");
        System.out.println("4. Ver el arreglo de forma descendente.");
        System.out.println("5. Ver si el arreglo está vacío");
        System.out.println("6. Buscar el mejor lugar para insetar el número");
        System.out.println("0. Salir del sistema.");
        System.out.println("Ingrese su opcion");
        opc=teclado.nextInt();
        switch(opc){
            case 1:
            System.out.println("Por favor ingrese un número entero para insertar en el array");
            int insertar = teclado.nextInt();
            insertarDato(insertar);
            break;
            case 2:
            System.out.println("Por favor ingrese el número que desea eliminar");
            int eliminar = teclado.nextInt();
            elimina(eliminar);
            break;
            case 3:
            ascendente(); 
            break;
            case 4:
            descendente();
            break;
            case 5:
            if(vacio()){
                System.out.println("El arreglo esta vacio");
            }else {
                System.out.println("El arreglo no esta vacio");
            }
            break;
            case 6:
            lugar();
            break;



             

        }
        }while (opc != 0); //Este while va "conectado" al "do" de arriba

        
    }
    
}

